Kbdlight
========

kbdlight is very simple application that changes MacBooks' keyboard
backlight level.

While usable standalone, the main goal is for it to be used by other
applications, including things like sxhkd or xbindkeys.

Usage
-----
Usage is ridiculously simple:

    kbdlight [up|down|off|max]


Copyright (c) 2013, Hugo Osvaldo Barrera <hugo@osvaldobarrera.com.ar>
